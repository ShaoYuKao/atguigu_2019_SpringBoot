package com.atguigu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringBoot07Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot07Application.class, args);
	}
}
